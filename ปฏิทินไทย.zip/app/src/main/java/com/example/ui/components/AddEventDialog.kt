package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ThaiDateUtils
import com.example.ui.theme.ThaiCrimsonPrimary
import com.example.ui.theme.ThaiFridayBlue
import com.example.ui.theme.ThaiGoldSecondary
import com.example.ui.theme.ThaiHolidayRed
import com.example.ui.theme.ThaiSaturdayPurple
import com.example.ui.theme.ThaiWednesdayGreen
import java.time.LocalDate

@Composable
fun AddEventDialog(
    selectedDate: LocalDate,
    onDismiss: () -> Unit,
    onSave: (title: String, description: String, time: String, isPushEnabled: Boolean, colorHex: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("09:00") }
    var isPushEnabled by remember { mutableStateOf(true) }
    var selectedColor by remember { mutableStateOf("#9E1B1B") }

    val presetTimes = listOf("08:00", "09:00", "12:00", "14:00", "18:00", "20:00")
    val presetColors = listOf(
        Pair("#9E1B1B", ThaiCrimsonPrimary),
        Pair("#D4AF37", ThaiGoldSecondary),
        Pair("#2E7D32", ThaiWednesdayGreen),
        Pair("#0288D1", ThaiFridayBlue),
        Pair("#7B1FA2", ThaiSaturdayPurple)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "เพิ่มกิจกรรม / เตือนความจำ",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ThaiCrimsonPrimary
                )
                Text(
                    text = ThaiDateUtils.formatFullThaiDate(selectedDate),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("ชื่อกิจกรรม / บันทึก *") },
                    placeholder = { Text("เช่น ประชุม, ไปทำบุญ, เที่ยววันหยุด") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_event_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("รายละเอียดเพิ่มเติม") },
                    placeholder = { Text("สถานที่ บันทึกข้อความ หรือนัดหมาย") },
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_event_desc")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "เวลาแจ้งเตือน",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetTimes.take(4).forEach { preset ->
                        val isPresetSelected = time == preset
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isPresetSelected) ThaiCrimsonPrimary else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { time = preset }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = preset,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isPresetSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isPresetSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("ระบุเวลา (ชั่วโมง:นาที)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Alarm, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Push Notification Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = if (isPushEnabled) ThaiCrimsonPrimary else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "ส่งการแจ้งเตือนแบบ Push",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "แจ้งเตือนผ่านแถบการแจ้งเตือนเมื่อถึงเวลา",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Switch(
                        checked = isPushEnabled,
                        onCheckedChange = { isPushEnabled = it },
                        modifier = Modifier.testTag("switch_push_notification"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ThaiCrimsonPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Color picker
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "แท็กสี:",
                        style = MaterialTheme.typography.labelMedium
                    )
                    presetColors.forEach { (hex, color) ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(color)
                                .clickable { selectedColor = hex }
                                .then(
                                    if (selectedColor == hex) Modifier.border(2.dp, Color.White, CircleShape) else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selectedColor == hex) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(title, description, time, isPushEnabled, selectedColor)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ThaiCrimsonPrimary),
                modifier = Modifier.testTag("btn_save_event")
            ) {
                Text("บันทึก")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("ยกเลิก")
            }
        }
    )
}
