package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.CalendarEvent
import com.example.data.model.HolidayCategory
import com.example.data.model.ThaiDateUtils
import com.example.data.model.ThaiHoliday
import com.example.data.model.WanPhraDay
import com.example.ui.theme.ThaiCrimsonPrimary
import com.example.ui.theme.ThaiFridayBlue
import com.example.ui.theme.ThaiGoldSecondary
import com.example.ui.theme.ThaiHolidayLightRed
import com.example.ui.theme.ThaiHolidayRed
import com.example.ui.theme.ThaiMondayYellow
import com.example.ui.theme.ThaiSaturdayPurple
import com.example.ui.theme.ThaiSundayRed
import com.example.ui.theme.ThaiThursdayOrange
import com.example.ui.theme.ThaiTuesdayPink
import com.example.ui.theme.ThaiWanPhraAmber
import com.example.ui.theme.ThaiWanPhraLight
import com.example.ui.theme.ThaiWednesdayGreen
import java.time.DayOfWeek
import java.time.LocalDate

@Composable
fun ThaiDayOfWeekHeaders(modifier: Modifier = Modifier) {
    val days = listOf(
        Pair("อา.", ThaiSundayRed),
        Pair("จ.", ThaiMondayYellow),
        Pair("อ.", ThaiTuesdayPink),
        Pair("พ.", ThaiWednesdayGreen),
        Pair("พฤ.", ThaiThursdayOrange),
        Pair("ศ.", ThaiFridayBlue),
        Pair("ส.", ThaiSaturdayPurple)
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        days.forEach { (label, color) ->
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .size(width = 16.dp, height = 2.dp)
                            .clip(RoundedCornerShape(1.dp))
                            .background(color.copy(alpha = 0.6f))
                    )
                }
            }
        }
    }
}

@Composable
fun CalendarDayCell(
    date: LocalDate,
    isCurrentMonth: Boolean,
    isSelected: Boolean,
    isToday: Boolean,
    holiday: ThaiHoliday?,
    wanPhra: WanPhraDay?,
    eventsCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSunday = date.dayOfWeek == DayOfWeek.SUNDAY
    val isHoliday = holiday != null

    val textColor = when {
        !isCurrentMonth -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f)
        isSelected -> MaterialTheme.colorScheme.onPrimary
        isHoliday || isSunday -> ThaiHolidayRed
        else -> MaterialTheme.colorScheme.onSurface
    }

    val cellBackground = when {
        isSelected -> ThaiCrimsonPrimary
        isToday -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        isHoliday && isCurrentMonth -> ThaiHolidayLightRed.copy(alpha = 0.6f)
        else -> Color.Transparent
    }

    Box(
        modifier = modifier
            .padding(2.dp)
            .height(52.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(cellBackground)
            .then(
                if (isToday && !isSelected) {
                    Modifier.border(1.5.dp, ThaiCrimsonPrimary, RoundedCornerShape(10.dp))
                } else Modifier
            )
            .clickable(onClick = onClick)
            .testTag("day_cell_${date}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
        ) {
            // Day number
            Text(
                text = date.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isSelected || isToday || isHoliday) FontWeight.Bold else FontWeight.Normal,
                color = textColor,
                fontSize = 15.sp
            )

            // Indicators row (Holiday badge dot, Wan Phra icon, Events dot)
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(14.dp)
            ) {
                if (isHoliday && isCurrentMonth) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.White else ThaiHolidayRed)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                }

                if (wanPhra != null && isCurrentMonth) {
                    Text(
                        text = "🙏",
                        fontSize = 8.sp,
                        modifier = Modifier.padding(horizontal = 1.dp)
                    )
                }

                if (eventsCount > 0 && isCurrentMonth) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.White else ThaiGoldSecondary)
                    )
                }
            }
        }
    }
}

@Composable
fun ThaiHolidayCard(
    holiday: ThaiHoliday,
    onTestPush: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("holiday_card_${holiday.nameTh}"),
        colors = CardDefaults.cardColors(
            containerColor = ThaiHolidayLightRed
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ThaiHolidayRed,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = holiday.category.thaiName,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = ThaiHolidayRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = ThaiDateUtils.formatShortThaiDate(holiday.date),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ThaiHolidayRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = holiday.nameTh,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = ThaiHolidayRed
            )

            if (holiday.nameEn.isNotBlank()) {
                Text(
                    text = holiday.nameEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (holiday.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = holiday.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            FilledTonalButton(
                onClick = onTestPush,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_test_push_holiday"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("ทดสอบส่งแจ้งเตือนวันหยุดนี้ (Push Alert)")
            }
        }
    }
}

@Composable
fun WanPhraCard(
    wanPhra: WanPhraDay,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("wan_phra_card"),
        colors = CardDefaults.cardColors(
            containerColor = ThaiWanPhraLight
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(ThaiWanPhraAmber.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text("🙏", fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "วันพระ (วันธรรมสวนะ)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = ThaiWanPhraAmber
                )
                Text(
                    text = wanPhra.descriptionTh,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                )
            }
        }
    }
}

@Composable
fun EventItemCard(
    event: CalendarEvent,
    onToggleComplete: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("event_item_${event.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.outlinedCardColors(
            containerColor = if (event.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (event.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = "ทำเสร็จแล้ว",
                    tint = if (event.isCompleted) ThaiWednesdayGreen else MaterialTheme.colorScheme.outline
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (event.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (event.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface
                )

                if (event.description.isNotBlank()) {
                    Text(
                        text = event.description,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (event.timeString.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = null,
                            tint = ThaiCrimsonPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${event.timeString} น.",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = ThaiCrimsonPrimary
                        )

                        if (event.isPushNotificationEnabled) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "เปิดแจ้งเตือน",
                                tint = ThaiGoldSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "Push แจ้งเตือน",
                                style = MaterialTheme.typography.labelSmall,
                                color = ThaiGoldSecondary
                            )
                        }
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "ลบรายการ",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                )
            }
        }
    }
}
