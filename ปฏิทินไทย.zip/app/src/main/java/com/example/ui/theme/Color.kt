package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Thai Theme Primary & Secondary Colors
val ThaiCrimsonPrimary = Color(0xFF9E1B1B)
val ThaiCrimsonOnPrimary = Color(0xFFFFFFFF)
val ThaiCrimsonPrimaryContainer = Color(0xFFFFDAD6)
val ThaiCrimsonOnPrimaryContainer = Color(0xFF410002)

val ThaiGoldSecondary = Color(0xFF855400)
val ThaiGoldOnSecondary = Color(0xFFFFFFFF)
val ThaiGoldSecondaryContainer = Color(0xFFFFDDB3)
val ThaiGoldOnSecondaryContainer = Color(0xFF2A1700)

val ThaiTertiary = Color(0xFF006874)
val ThaiOnTertiary = Color(0xFFFFFFFF)
val ThaiTertiaryContainer = Color(0xFF9EEFFD)
val ThaiOnTertiaryContainer = Color(0xFF001F24)

// Holiday & Day Indicators
val ThaiHolidayRed = Color(0xFFD32F2F)
val ThaiHolidayLightRed = Color(0xFFFFEBEE)
val ThaiWanPhraAmber = Color(0xFFE65100)
val ThaiWanPhraLight = Color(0xFFFFF3E0)

// Traditional Thai 7-day colors
val ThaiSundayRed = Color(0xFFD32F2F)
val ThaiMondayYellow = Color(0xFFE0A100)
val ThaiTuesdayPink = Color(0xFFD81B60)
val ThaiWednesdayGreen = Color(0xFF2E7D32)
val ThaiThursdayOrange = Color(0xFFEF6C00)
val ThaiFridayBlue = Color(0xFF0288D1)
val ThaiSaturdayPurple = Color(0xFF7B1FA2)

// Dark Theme Colors
val ThaiCrimsonPrimaryDark = Color(0xFFFFB4AB)
val ThaiCrimsonOnPrimaryDark = Color(0xFF690005)
val ThaiCrimsonPrimaryContainerDark = Color(0xFF82000A)
val ThaiCrimsonOnPrimaryContainerDark = Color(0xFFFFDAD6)

val ThaiGoldSecondaryDark = Color(0xFFFFB951)
val ThaiGoldOnSecondaryDark = Color(0xFF462A00)
val ThaiGoldSecondaryContainerDark = Color(0xFF653E00)
val ThaiGoldOnSecondaryContainerDark = Color(0xFFFFDDB3)
