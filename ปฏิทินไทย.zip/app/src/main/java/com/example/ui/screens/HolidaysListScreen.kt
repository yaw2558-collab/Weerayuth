package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HolidayCategory
import com.example.data.model.ThaiDateUtils
import com.example.data.model.ThaiHoliday
import com.example.ui.theme.ThaiCrimsonPrimary
import com.example.ui.theme.ThaiGoldSecondary
import com.example.ui.theme.ThaiHolidayLightRed
import com.example.ui.theme.ThaiHolidayRed
import com.example.ui.theme.ThaiWanPhraAmber
import com.example.ui.theme.ThaiWanPhraLight
import com.example.ui.viewmodel.CalendarViewModel
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@Composable
fun HolidaysListScreen(
    viewModel: CalendarViewModel,
    onSelectDate: (LocalDate) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentYearMonth by viewModel.currentYearMonth.collectAsState()
    val yearHolidays by viewModel.yearHolidays.collectAsState()
    val yearWanPhraDays by viewModel.yearWanPhraDays.collectAsState()
    val selectedFilter by viewModel.holidayFilter.collectAsState()

    var showWanPhraList by remember { mutableStateOf(false) }

    val today = LocalDate.now()
    val buddhistYear = ThaiDateUtils.toBuddhistYear(currentYearMonth.year)

    // Upcoming holiday calculation
    val upcomingHoliday = remember(yearHolidays, today) {
        yearHolidays.firstOrNull { !it.date.isBefore(today) }
    }

    val daysUntilUpcoming = upcomingHoliday?.let {
        ChronoUnit.DAYS.between(today, it.date)
    }

    // Filtered holidays
    val filteredHolidays = remember(yearHolidays, selectedFilter) {
        if (selectedFilter == null) {
            yearHolidays
        } else {
            yearHolidays.filter { it.category == selectedFilter }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Year Navigation Header
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "วันหยุดนักขัตฤกษ์",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = ThaiCrimsonPrimary
                    )
                    Text(
                        text = "ประจำปี พ.ศ. $buddhistYear (ค.ศ. ${currentYearMonth.year})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.setYearMonth(currentYearMonth.year - 1, currentYearMonth.monthValue) },
                        modifier = Modifier.testTag("btn_prev_year")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ปีก่อนหน้า")
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "$buddhistYear",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ThaiCrimsonPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.setYearMonth(currentYearMonth.year + 1, currentYearMonth.monthValue) },
                        modifier = Modifier.testTag("btn_next_year")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "ปีถัดไป")
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Upcoming Holiday Feature Card
        item {
            if (upcomingHoliday != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upcoming_holiday_banner"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = ThaiCrimsonPrimary
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Celebration,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "วันหยุดถัดไป",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            if (daysUntilUpcoming != null) {
                                Surface(
                                    color = ThaiGoldSecondary,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Timer,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (daysUntilUpcoming == 0L) "วันนี้!" else "อีก $daysUntilUpcoming วัน",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = upcomingHoliday.nameTh,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Text(
                            text = ThaiDateUtils.formatFullThaiDate(upcomingHoliday.date),
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )

                        if (upcomingHoliday.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = upcomingHoliday.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.triggerHolidayPush(upcomingHoliday) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = ThaiCrimsonPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ทดสอบส่งการแจ้งเตือน Push วันนี้",
                                color = ThaiCrimsonPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Filter chips row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedFilter == null && !showWanPhraList,
                        onClick = {
                            viewModel.setHolidayFilter(null)
                            showWanPhraList = false
                        },
                        label = { Text("ทั้งหมด (${yearHolidays.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ThaiCrimsonPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                item {
                    val publicCount = yearHolidays.count { it.category == HolidayCategory.PUBLIC_HOLIDAY }
                    FilterChip(
                        selected = selectedFilter == HolidayCategory.PUBLIC_HOLIDAY && !showWanPhraList,
                        onClick = {
                            viewModel.setHolidayFilter(HolidayCategory.PUBLIC_HOLIDAY)
                            showWanPhraList = false
                        },
                        label = { Text("วันหยุดราชการ ($publicCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ThaiCrimsonPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                item {
                    val buddhistCount = yearHolidays.count { it.category == HolidayCategory.BUDDHIST_HOLIDAY }
                    FilterChip(
                        selected = selectedFilter == HolidayCategory.BUDDHIST_HOLIDAY && !showWanPhraList,
                        onClick = {
                            viewModel.setHolidayFilter(HolidayCategory.BUDDHIST_HOLIDAY)
                            showWanPhraList = false
                        },
                        label = { Text("วันสำคัญทางพุทธ ($buddhistCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ThaiCrimsonPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                item {
                    val subCount = yearHolidays.count { it.category == HolidayCategory.SUBSTITUTE_HOLIDAY }
                    FilterChip(
                        selected = selectedFilter == HolidayCategory.SUBSTITUTE_HOLIDAY && !showWanPhraList,
                        onClick = {
                            viewModel.setHolidayFilter(HolidayCategory.SUBSTITUTE_HOLIDAY)
                            showWanPhraList = false
                        },
                        label = { Text("วันหยุดชดเชย ($subCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ThaiCrimsonPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                item {
                    FilterChip(
                        selected = showWanPhraList,
                        onClick = { showWanPhraList = true },
                        label = { Text("วันพระ (${yearWanPhraDays.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ThaiWanPhraAmber,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // List Content: Wan Phra List or Holiday List
        if (showWanPhraList) {
            items(yearWanPhraDays) { wp ->
                val isPast = wp.date.isBefore(today)
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.outlinedCardColors(
                        containerColor = if (isPast) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else ThaiWanPhraLight
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🙏", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = wp.descriptionTh,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = ThaiWanPhraAmber
                                )
                                Text(
                                    text = ThaiDateUtils.formatFullThaiDate(wp.date),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                viewModel.selectDate(wp.date)
                                onSelectDate(wp.date)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "ดูในปฏิทิน",
                                tint = ThaiWanPhraAmber
                            )
                        }
                    }
                }
            }
        } else {
            items(filteredHolidays) { holiday ->
                val isPast = holiday.date.isBefore(today)
                val isCurrentToday = holiday.date == today

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .testTag("holiday_item_${holiday.nameTh}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isCurrentToday -> ThaiHolidayLightRed
                            isPast -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            else -> MaterialTheme.colorScheme.surface
                        }
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (isPast) 0.dp else 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(modifier = Modifier.weight(1f)) {
                                // Date Block
                                Surface(
                                    color = if (isPast) MaterialTheme.colorScheme.outline.copy(alpha = 0.2f) else ThaiHolidayRed,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(width = 54.dp, height = 54.dp)
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = holiday.date.dayOfMonth.toString(),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isPast) MaterialTheme.colorScheme.onSurfaceVariant else Color.White
                                        )
                                        Text(
                                            text = ThaiDateUtils.getMonthShortNameTh(holiday.date.monthValue),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isPast) MaterialTheme.colorScheme.onSurfaceVariant else Color.White.copy(alpha = 0.9f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = holiday.nameTh,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPast) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else ThaiCrimsonPrimary
                                    )

                                    if (holiday.nameEn.isNotBlank()) {
                                        Text(
                                            text = holiday.nameEn,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        color = if (isPast) MaterialTheme.colorScheme.surfaceVariant else ThaiHolidayLightRed,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = holiday.category.thaiName,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isPast) MaterialTheme.colorScheme.onSurfaceVariant else ThaiHolidayRed,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Action button: Test push alert
                            IconButton(
                                onClick = { viewModel.triggerHolidayPush(holiday) },
                                modifier = Modifier.testTag("btn_push_${holiday.nameTh}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "ส่งแจ้งเตือนแบบ Push",
                                    tint = ThaiCrimsonPrimary
                                )
                            }
                        }

                        if (holiday.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = holiday.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                            )
                        }
                    }
                }
            }
        }
    }
}
