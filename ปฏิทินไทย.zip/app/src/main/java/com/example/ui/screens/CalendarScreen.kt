package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.CalendarEvent
import com.example.data.model.ThaiDateUtils
import com.example.data.model.ThaiHoliday
import com.example.ui.components.AddEventDialog
import com.example.ui.components.CalendarDayCell
import com.example.ui.components.EventItemCard
import com.example.ui.components.ThaiDayOfWeekHeaders
import com.example.ui.components.ThaiHolidayCard
import com.example.ui.components.WanPhraCard
import com.example.ui.theme.ThaiCrimsonPrimary
import com.example.ui.theme.ThaiGoldSecondary
import com.example.ui.theme.ThaiHolidayLightRed
import com.example.ui.theme.ThaiHolidayRed
import com.example.ui.viewmodel.CalendarViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen(
    viewModel: CalendarViewModel,
    onNavigateToHolidays: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentYearMonth by viewModel.currentYearMonth.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val yearHolidays by viewModel.yearHolidays.collectAsState()
    val yearWanPhraDays by viewModel.yearWanPhraDays.collectAsState()
    val selectedEvents by viewModel.selectedDateEvents.collectAsState()
    val allEvents by viewModel.allEvents.collectAsState()

    var showAddEventDialog by remember { mutableStateOf(false) }

    val today = LocalDate.now()
    val buddhistYear = ThaiDateUtils.toBuddhistYear(currentYearMonth.year)
    val monthName = ThaiDateUtils.getMonthNameTh(currentYearMonth.monthValue)

    // Holidays in current month
    val monthHolidays = remember(yearHolidays, currentYearMonth) {
        yearHolidays.filter { it.date.year == currentYearMonth.year && it.date.monthValue == currentYearMonth.monthValue }
    }

    // Selected day holiday & wan phra
    val selectedDayHoliday = remember(yearHolidays, selectedDate) {
        yearHolidays.firstOrNull { it.date == selectedDate }
    }
    val selectedDayWanPhra = remember(yearWanPhraDays, selectedDate) {
        yearWanPhraDays.firstOrNull { it.date == selectedDate }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Month & Year Header Controller
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "$monthName พ.ศ. $buddhistYear",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = ThaiCrimsonPrimary
                        )
                        Text(
                            text = "${currentYearMonth.month.name} ${currentYearMonth.year}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = { viewModel.goToToday() },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_go_today")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Today,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = ThaiCrimsonPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("วันนี้", style = MaterialTheme.typography.labelMedium)
                        }

                        IconButton(
                            onClick = { viewModel.previousMonth() },
                            modifier = Modifier.testTag("btn_prev_month")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "เดือนก่อนหน้า"
                            )
                        }

                        IconButton(
                            onClick = { viewModel.nextMonth() },
                            modifier = Modifier.testTag("btn_next_month")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "เดือนถัดไป"
                            )
                        }
                    }
                }
            }

            // Month summary chips
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = ThaiHolidayLightRed,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(ThaiHolidayRed)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "วันหยุดเดือนนี้: ${monthHolidays.size} วัน",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = ThaiHolidayRed
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🙏", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "มีเครื่องหมายวันพระ",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Day of Week Headers (อา. จ. อ. พ. พฤ. ศ. ส.)
            item {
                ThaiDayOfWeekHeaders()
            }

            // Calendar Month Grid (42 cells: 6 weeks x 7 days)
            item {
                val firstDayOfMonth = currentYearMonth.atDay(1)
                // In Thai calendar, Sunday is day 0
                val firstDayOfWeekIndex = when (firstDayOfMonth.dayOfWeek) {
                    DayOfWeek.SUNDAY -> 0
                    DayOfWeek.MONDAY -> 1
                    DayOfWeek.TUESDAY -> 2
                    DayOfWeek.WEDNESDAY -> 3
                    DayOfWeek.THURSDAY -> 4
                    DayOfWeek.FRIDAY -> 5
                    DayOfWeek.SATURDAY -> 6
                }

                val daysInMonth = currentYearMonth.lengthOfMonth()
                val calendarStartDate = firstDayOfMonth.minusDays(firstDayOfWeekIndex.toLong())

                Column(modifier = Modifier.fillMaxWidth()) {
                    for (week in 0 until 6) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (dayOfWeek in 0 until 7) {
                                val cellDate = calendarStartDate.plusDays((week * 7 + dayOfWeek).toLong())
                                val isCurrentMonth = cellDate.monthValue == currentYearMonth.monthValue
                                val isSelected = cellDate == selectedDate
                                val isCellToday = cellDate == today

                                val cellHoliday = yearHolidays.firstOrNull { it.date == cellDate }
                                val cellWanPhra = yearWanPhraDays.firstOrNull { it.date == cellDate }
                                val cellEventsCount = allEvents.count { it.dateString == cellDate.toString() }

                                Box(modifier = Modifier.weight(1f)) {
                                    CalendarDayCell(
                                        date = cellDate,
                                        isCurrentMonth = isCurrentMonth,
                                        isSelected = isSelected,
                                        isToday = isCellToday,
                                        holiday = cellHoliday,
                                        wanPhra = cellWanPhra,
                                        eventsCount = cellEventsCount,
                                        onClick = { viewModel.selectDate(cellDate) }
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Selected Date Detail Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = ThaiDateUtils.formatFullThaiDate(selectedDate),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ThaiCrimsonPrimary
                                )
                                Text(
                                    text = if (selectedDate == today) "🌟 วันนี้" else "วันที่เลือก",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ThaiGoldSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = { showAddEventDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ThaiCrimsonPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_add_event_for_date")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("เพิ่มบันทึก", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        // Holiday Card if today has holiday
                        if (selectedDayHoliday != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            ThaiHolidayCard(
                                holiday = selectedDayHoliday,
                                onTestPush = { viewModel.triggerHolidayPush(selectedDayHoliday) }
                            )
                        }

                        // Wan Phra Card if today is Wan Phra
                        if (selectedDayWanPhra != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            WanPhraCard(wanPhra = selectedDayWanPhra)
                        }

                        // User events for this day
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EventNote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "กิจกรรม & บันทึกเตือนความจำ (${selectedEvents.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (selectedEvents.isEmpty()) {
                            Text(
                                text = "ไม่มีกิจกรรมหรือบันทึกเตือนความจำในวันนี้ กดปุ่ม 'เพิ่มบันทึก' เพื่อตั้งเตือนความจำแบบ Push",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            selectedEvents.forEach { event ->
                                EventItemCard(
                                    event = event,
                                    onToggleComplete = { viewModel.toggleEventCompleted(event) },
                                    onDelete = { viewModel.deleteEvent(event) }
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Add Event Dialog
        if (showAddEventDialog) {
            AddEventDialog(
                selectedDate = selectedDate,
                onDismiss = { showAddEventDialog = false },
                onSave = { title, desc, time, isPush, color ->
                    viewModel.addEvent(
                        title = title,
                        description = desc,
                        date = selectedDate,
                        time = time,
                        isPushEnabled = isPush,
                        colorHex = color
                    )
                    showAddEventDialog = false
                }
            )
        }
    }
}
