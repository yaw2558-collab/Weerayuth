package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.CalendarEvent
import com.example.data.database.NotificationLog
import com.example.data.model.HolidayCategory
import com.example.data.model.ThaiDateUtils
import com.example.data.model.ThaiHoliday
import com.example.data.model.WanPhraDay
import com.example.data.repository.CalendarRepository
import com.example.notification.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

class CalendarViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CalendarRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = CalendarRepository(db.calendarDao())
        NotificationHelper.createNotificationChannels(application)
    }

    // Current displayed YearMonth in the calendar grid
    private val _currentYearMonth = MutableStateFlow(YearMonth.now())
    val currentYearMonth: StateFlow<YearMonth> = _currentYearMonth.asStateFlow()

    // Current selected date by user
    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    // Selected holiday filter in Holidays screen
    private val _holidayFilter = MutableStateFlow<HolidayCategory?>(null)
    val holidayFilter: StateFlow<HolidayCategory?> = _holidayFilter.asStateFlow()

    // Holidays for currently selected year
    private val _yearHolidays = MutableStateFlow<List<ThaiHoliday>>(emptyList())
    val yearHolidays: StateFlow<List<ThaiHoliday>> = _yearHolidays.asStateFlow()

    // Wan Phra days for currently selected year
    private val _yearWanPhraDays = MutableStateFlow<List<WanPhraDay>>(emptyList())
    val yearWanPhraDays: StateFlow<List<WanPhraDay>> = _yearWanPhraDays.asStateFlow()

    // Notification preferences
    private val prefs = application.getSharedPreferences("thai_calendar_prefs", Context.MODE_PRIVATE)
    private val _notifyHolidayMorning = MutableStateFlow(prefs.getBoolean("pref_holiday_morning", true))
    val notifyHolidayMorning: StateFlow<Boolean> = _notifyHolidayMorning.asStateFlow()

    private val _notifyHolidayAdvance = MutableStateFlow(prefs.getBoolean("pref_holiday_advance", true))
    val notifyHolidayAdvance: StateFlow<Boolean> = _notifyHolidayAdvance.asStateFlow()

    private val _notifyWanPhra = MutableStateFlow(prefs.getBoolean("pref_wan_phra", true))
    val notifyWanPhra: StateFlow<Boolean> = _notifyWanPhra.asStateFlow()

    // Events for currently selected date
    val selectedDateEvents: StateFlow<List<CalendarEvent>> = _selectedDate
        .flatMapLatest { date ->
            repository.getEventsForDate(date.toString())
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // All events (used to draw dots/badges on calendar grid)
    val allEvents: StateFlow<List<CalendarEvent>> = repository.allEvents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Notification logs
    val notificationLogs: StateFlow<List<NotificationLog>> = repository.notificationLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        loadHolidaysForYear(_currentYearMonth.value.year)
    }

    fun previousMonth() {
        val prev = _currentYearMonth.value.minusMonths(1)
        _currentYearMonth.value = prev
        if (prev.year != _selectedDate.value.year) {
            loadHolidaysForYear(prev.year)
        }
    }

    fun nextMonth() {
        val next = _currentYearMonth.value.plusMonths(1)
        _currentYearMonth.value = next
        if (next.year != _selectedDate.value.year) {
            loadHolidaysForYear(next.year)
        }
    }

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
        if (date.year != _currentYearMonth.value.year || date.month != _currentYearMonth.value.month) {
            _currentYearMonth.value = YearMonth.of(date.year, date.month)
            loadHolidaysForYear(date.year)
        }
    }

    fun goToToday() {
        val today = LocalDate.now()
        _selectedDate.value = today
        _currentYearMonth.value = YearMonth.of(today.year, today.month)
        loadHolidaysForYear(today.year)
    }

    fun setYearMonth(year: Int, month: Int) {
        _currentYearMonth.value = YearMonth.of(year, month)
        loadHolidaysForYear(year)
    }

    fun setHolidayFilter(category: HolidayCategory?) {
        _holidayFilter.value = category
    }

    private fun loadHolidaysForYear(year: Int) {
        _yearHolidays.value = ThaiDateUtils.getHolidaysForYear(year)
        _yearWanPhraDays.value = ThaiDateUtils.getWanPhraDaysForYear(year)
    }

    // Event operations
    fun addEvent(
        title: String,
        description: String,
        date: LocalDate,
        time: String,
        isPushEnabled: Boolean,
        colorHex: String
    ) {
        viewModelScope.launch {
            val event = CalendarEvent(
                dateString = date.toString(),
                title = title.trim(),
                description = description.trim(),
                timeString = time.trim(),
                isPushNotificationEnabled = isPushEnabled,
                colorHex = colorHex
            )
            val newId = repository.insertEvent(event)
            if (isPushEnabled) {
                NotificationHelper.scheduleEventAlarm(
                    context = getApplication(),
                    eventId = newId,
                    dateString = event.dateString,
                    timeString = event.timeString,
                    title = event.title,
                    details = event.description
                )
            }
        }
    }

    fun deleteEvent(event: CalendarEvent) {
        viewModelScope.launch {
            NotificationHelper.cancelEventAlarm(getApplication(), event.id)
            repository.deleteEvent(event)
        }
    }

    fun toggleEventCompleted(event: CalendarEvent) {
        viewModelScope.launch {
            val updated = event.copy(isCompleted = !event.isCompleted)
            repository.updateEvent(updated)
        }
    }

    // Notification testing & triggers
    fun triggerInstantTestPush() {
        viewModelScope.launch {
            val title = "🎉 ทดสอบการแจ้งเตือนแบบ Push"
            val message = "ระบบแจ้งเตือนปฏิทินไทยพร้อมใช้งาน! รองรับการแจ้งเตือนวันหยุดนักขัตฤกษ์และเตือนความจำ"
            NotificationHelper.postNotification(
                context = getApplication(),
                notificationId = (System.currentTimeMillis() % 100000).toInt(),
                channelId = NotificationHelper.CHANNEL_REMINDERS,
                title = title,
                message = message,
                subText = "ปฏิทินไทย"
            )
            repository.logNotification(title, message, "TEST")
        }
    }

    fun triggerHolidayPush(holiday: ThaiHoliday) {
        viewModelScope.launch {
            val title = "📢 แจ้งเตือนวันหยุด: ${holiday.nameTh}"
            val dateText = ThaiDateUtils.formatFullThaiDate(holiday.date)
            val message = "$dateText เป็น${holiday.category.thaiName} (${holiday.description.ifBlank { holiday.nameEn }})"
            NotificationHelper.postNotification(
                context = getApplication(),
                notificationId = (holiday.date.toEpochDay() % 100000).toInt(),
                channelId = NotificationHelper.CHANNEL_HOLIDAYS,
                title = title,
                message = message,
                subText = holiday.category.thaiName
            )
            repository.logNotification(title, message, "HOLIDAY")
        }
    }

    fun clearNotificationHistory() {
        viewModelScope.launch {
            repository.clearNotificationLogs()
        }
    }

    fun setNotifyHolidayMorning(enabled: Boolean) {
        _notifyHolidayMorning.value = enabled
        prefs.edit().putBoolean("pref_holiday_morning", enabled).apply()
    }

    fun setNotifyHolidayAdvance(enabled: Boolean) {
        _notifyHolidayAdvance.value = enabled
        prefs.edit().putBoolean("pref_holiday_advance", enabled).apply()
    }

    fun setNotifyWanPhra(enabled: Boolean) {
        _notifyWanPhra.value = enabled
        prefs.edit().putBoolean("pref_wan_phra", enabled).apply()
    }
}
