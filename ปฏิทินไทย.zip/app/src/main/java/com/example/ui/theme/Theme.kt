package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ThaiCrimsonPrimaryDark,
    onPrimary = ThaiCrimsonOnPrimaryDark,
    primaryContainer = ThaiCrimsonPrimaryContainerDark,
    onPrimaryContainer = ThaiCrimsonOnPrimaryContainerDark,
    secondary = ThaiGoldSecondaryDark,
    onSecondary = ThaiGoldOnSecondaryDark,
    secondaryContainer = ThaiGoldSecondaryContainerDark,
    onSecondaryContainer = ThaiGoldOnSecondaryContainerDark
)

private val LightColorScheme = lightColorScheme(
    primary = ThaiCrimsonPrimary,
    onPrimary = ThaiCrimsonOnPrimary,
    primaryContainer = ThaiCrimsonPrimaryContainer,
    onPrimaryContainer = ThaiCrimsonOnPrimaryContainer,
    secondary = ThaiGoldSecondary,
    onSecondary = ThaiGoldOnSecondary,
    secondaryContainer = ThaiGoldSecondaryContainer,
    onSecondaryContainer = ThaiGoldOnSecondaryContainer,
    tertiary = ThaiTertiary,
    onTertiary = ThaiOnTertiary,
    tertiaryContainer = ThaiTertiaryContainer,
    onTertiaryContainer = ThaiOnTertiaryContainer
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our handcrafted rich Thai theme
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
