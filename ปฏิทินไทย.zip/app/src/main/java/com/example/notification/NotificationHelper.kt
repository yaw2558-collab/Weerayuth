package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object NotificationHelper {

    const val CHANNEL_HOLIDAYS = "channel_thai_holidays"
    const val CHANNEL_REMINDERS = "channel_thai_reminders"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val holidayChannel = NotificationChannel(
                CHANNEL_HOLIDAYS,
                "แจ้งเตือนวันหยุดนักขัตฤกษ์",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "การแจ้งเตือนวันหยุดราชการ วันหยุดนักขัตฤกษ์ และวันสำคัญไทย"
                enableVibration(true)
                enableLights(true)
                setShowBadge(true)
            }

            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "แจ้งเตือนบันทึกและกิจกรรม",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "การแจ้งเตือนเตือนความจำกิจกรรมและนัดหมายในปฏิทิน"
                enableVibration(true)
                enableLights(true)
                setShowBadge(true)
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(holidayChannel)
            manager.createNotificationChannel(reminderChannel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun postNotification(
        context: Context,
        notificationId: Int,
        channelId: String,
        title: String,
        message: String,
        subText: String? = null
    ) {
        if (!hasNotificationPermission(context)) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (subText != null) {
            builder.setSubText(subText)
        }

        try {
            val manager = NotificationManagerCompat.from(context)
            manager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Permission not granted
        }
    }

    fun sendImmediateTestHolidayNotification(context: Context, holidayName: String = "วันสงกรานต์ (เทศกาลสงกรานต์)") {
        postNotification(
            context = context,
            notificationId = (System.currentTimeMillis() % 100000).toInt(),
            channelId = CHANNEL_HOLIDAYS,
            title = "🎉 แจ้งเตือนวันหยุด: $holidayName",
            message = "วันหยุดนักขัตฤกษ์ใกล้ถึงแล้ว! เตรียมตัวพักผ่อน ทำบุญ และท่องเที่ยวกับครอบครัวอย่างมีความสุข",
            subText = "ปฏิทินไทย"
        )
    }

    fun sendImmediateTestReminderNotification(context: Context, title: String, content: String) {
        postNotification(
            context = context,
            notificationId = (System.currentTimeMillis() % 100000).toInt(),
            channelId = CHANNEL_REMINDERS,
            title = "⏰ เตือนความจำ: $title",
            message = content.ifBlank { "ถึงเวลากิจกรรมที่บันทึกไว้ในปฏิทินแล้ว" },
            subText = "นัดหมายปฏิทินไทย"
        )
    }

    fun scheduleEventAlarm(
        context: Context,
        eventId: Long,
        dateString: String, // "YYYY-MM-DD"
        timeString: String, // "HH:mm"
        title: String,
        details: String
    ) {
        try {
            val dateParts = dateString.split("-").map { it.toInt() }
            val timeParts = if (timeString.isNotBlank() && timeString.contains(":")) {
                timeString.split(":").map { it.toInt() }
            } else {
                listOf(9, 0)
            }

            val ldt = LocalDateTime.of(
                LocalDate.of(dateParts[0], dateParts[1], dateParts[2]),
                LocalTime.of(timeParts[0], timeParts[1])
            )

            val triggerMillis = ldt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

            if (triggerMillis <= System.currentTimeMillis()) {
                // If the time is in the past, do not schedule past alarm
                return
            }

            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, CalendarAlarmReceiver::class.java).apply {
                putExtra("eventId", eventId)
                putExtra("title", title)
                putExtra("message", details.ifBlank { "ถึงเวลานัดหมายในปฏิทินไทยแล้ว" })
                putExtra("channelId", CHANNEL_REMINDERS)
                putExtra("type", "REMINDER")
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                eventId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelEventAlarm(context: Context, eventId: Long) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, CalendarAlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                eventId.toInt(),
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
