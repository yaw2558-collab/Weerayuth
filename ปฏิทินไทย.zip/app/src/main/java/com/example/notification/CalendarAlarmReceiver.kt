package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.database.AppDatabase
import com.example.data.database.NotificationLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CalendarAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "แจ้งเตือนจากปฏิทินไทย"
        val message = intent.getStringExtra("message") ?: "ถึงเวลากิจกรรมที่บันทึกไว้"
        val channelId = intent.getStringExtra("channelId") ?: NotificationHelper.CHANNEL_REMINDERS
        val type = intent.getStringExtra("type") ?: "REMINDER"
        val eventId = intent.getLongExtra("eventId", 0L)

        val notificationId = if (eventId > 0) eventId.toInt() else (System.currentTimeMillis() % 100000).toInt()

        NotificationHelper.postNotification(
            context = context,
            notificationId = notificationId,
            channelId = channelId,
            title = title,
            message = message,
            subText = "ปฏิทินไทย"
        )

        // Log notification to local database
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                db.calendarDao().insertNotificationLog(
                    NotificationLog(
                        title = title,
                        message = message,
                        type = type,
                        timestamp = System.currentTimeMillis()
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                pendingResult.finish()
            }
        }
    }
}
