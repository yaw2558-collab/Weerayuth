package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.database.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            NotificationHelper.createNotificationChannels(context)

            // Reschedule active alarms
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getInstance(context)
                    val events = db.calendarDao().getAllEvents().first()
                    for (event in events) {
                        if (event.isPushNotificationEnabled && !event.isCompleted) {
                            NotificationHelper.scheduleEventAlarm(
                                context = context,
                                eventId = event.id,
                                dateString = event.dateString,
                                timeString = event.timeString,
                                title = event.title,
                                details = event.description
                            )
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
