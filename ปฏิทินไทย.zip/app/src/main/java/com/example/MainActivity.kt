package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Celebration
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ThaiDateUtils
import com.example.notification.NotificationHelper
import com.example.ui.components.AddEventDialog
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.HolidaysListScreen
import com.example.ui.screens.NotificationSettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ThaiCrimsonPrimary
import com.example.ui.theme.ThaiGoldSecondary
import com.example.ui.viewmodel.CalendarViewModel
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainActivity : ComponentActivity() {

    private val viewModel: CalendarViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create notification channels
        NotificationHelper.createNotificationChannels(this)

        setContent {
            MyApplicationTheme {
                val snackbarHostState = remember { SnackbarHostState() }
                val coroutineScope = rememberCoroutineScope()
                var currentTab by remember { mutableIntStateOf(0) }
                var showAddDialog by remember { mutableStateOf(false) }

                val selectedDate by viewModel.selectedDate.collectAsState()

                // Request notification permission on launch if needed (Android 13+)
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    if (isGranted) {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("เปิดรับการแจ้งเตือนแบบ Push เรียบร้อยแล้ว")
                        }
                    }
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (!NotificationHelper.hasNotificationPermission(this@MainActivity)) {
                            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                                    Text(
                                        text = "ปฏิทินไทย",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = ThaiCrimsonPrimary
                                    )
                                    Text(
                                        text = ThaiDateUtils.formatShortThaiDate(LocalDate.now()),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = {
                                        viewModel.triggerInstantTestPush()
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("ส่งการแจ้งเตือนแบบ Push ทดสอบแล้ว ตรวจสอบแถบแจ้งเตือนด้านบน")
                                        }
                                    },
                                    modifier = Modifier.testTag("top_bar_test_push")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = "ทดสอบส่งแจ้งเตือน",
                                        tint = ThaiCrimsonPrimary
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 0) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth,
                                        contentDescription = "ปฏิทิน"
                                    )
                                },
                                label = { Text("ปฏิทิน", fontWeight = if (currentTab == 0) FontWeight.Bold else FontWeight.Normal) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = ThaiCrimsonPrimary,
                                    indicatorColor = ThaiCrimsonPrimary
                                ),
                                modifier = Modifier.testTag("tab_calendar")
                            )

                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = { currentTab = 1 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 1) Icons.Filled.Celebration else Icons.Outlined.Celebration,
                                        contentDescription = "วันหยุด"
                                    )
                                },
                                label = { Text("วันหยุด", fontWeight = if (currentTab == 1) FontWeight.Bold else FontWeight.Normal) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = ThaiCrimsonPrimary,
                                    indicatorColor = ThaiCrimsonPrimary
                                ),
                                modifier = Modifier.testTag("tab_holidays")
                            )

                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 2) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                                        contentDescription = "แจ้งเตือน"
                                    )
                                },
                                label = { Text("แจ้งเตือน", fontWeight = if (currentTab == 2) FontWeight.Bold else FontWeight.Normal) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = ThaiCrimsonPrimary,
                                    indicatorColor = ThaiCrimsonPrimary
                                ),
                                modifier = Modifier.testTag("tab_notifications")
                            )
                        }
                    },
                    floatingActionButton = {
                        if (currentTab == 0) {
                            FloatingActionButton(
                                onClick = { showAddDialog = true },
                                containerColor = ThaiCrimsonPrimary,
                                contentColor = Color.White,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.testTag("fab_add_event")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "เพิ่มกิจกรรม"
                                )
                            }
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            0 -> CalendarScreen(
                                viewModel = viewModel,
                                onNavigateToHolidays = { currentTab = 1 },
                                onNavigateToNotifications = { currentTab = 2 }
                            )
                            1 -> HolidaysListScreen(
                                viewModel = viewModel,
                                onSelectDate = {
                                    currentTab = 0
                                }
                            )
                            2 -> NotificationSettingsScreen(
                                viewModel = viewModel
                            )
                        }
                    }

                    if (showAddDialog) {
                        AddEventDialog(
                            selectedDate = selectedDate,
                            onDismiss = { showAddDialog = false },
                            onSave = { title, desc, time, isPush, color ->
                                viewModel.addEvent(
                                    title = title,
                                    description = desc,
                                    date = selectedDate,
                                    time = time,
                                    isPushEnabled = isPush,
                                    colorHex = color
                                )
                                showAddDialog = false
                                coroutineScope.launch {
                                    val msg = if (isPush) "บันทึกและตั้งแจ้งเตือนแบบ Push สำเร็จ" else "บันทึกกิจกรรมสำเร็จ"
                                    snackbarHostState.showSnackbar(msg)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
