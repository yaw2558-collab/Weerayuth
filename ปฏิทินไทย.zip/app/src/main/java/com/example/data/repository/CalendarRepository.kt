package com.example.data.repository

import com.example.data.database.CalendarDao
import com.example.data.database.CalendarEvent
import com.example.data.database.NotificationLog
import kotlinx.coroutines.flow.Flow

class CalendarRepository(private val calendarDao: CalendarDao) {

    fun getEventsForDate(dateString: String): Flow<List<CalendarEvent>> =
        calendarDao.getEventsForDate(dateString)

    val allEvents: Flow<List<CalendarEvent>> = calendarDao.getAllEvents()

    val notificationLogs: Flow<List<NotificationLog>> = calendarDao.getAllNotificationLogs()

    suspend fun getEventById(id: Long): CalendarEvent? = calendarDao.getEventById(id)

    suspend fun insertEvent(event: CalendarEvent): Long = calendarDao.insertEvent(event)

    suspend fun updateEvent(event: CalendarEvent) = calendarDao.updateEvent(event)

    suspend fun deleteEvent(event: CalendarEvent) = calendarDao.deleteEvent(event)

    suspend fun deleteEventById(id: Long) = calendarDao.deleteEventById(id)

    suspend fun logNotification(title: String, message: String, type: String) {
        calendarDao.insertNotificationLog(
            NotificationLog(
                title = title,
                message = message,
                type = type
            )
        )
    }

    suspend fun clearNotificationLogs() = calendarDao.clearNotificationLogs()
}
