package com.example.data.model

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object ThaiDateUtils {

    val THAI_MONTHS_FULL = listOf(
        "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน",
        "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม",
        "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
    )

    val THAI_MONTHS_SHORT = listOf(
        "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.",
        "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.",
        "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."
    )

    val THAI_DAYS_OF_WEEK_SHORT = listOf(
        "อา.", "จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส."
    )

    val THAI_DAYS_OF_WEEK_FULL = listOf(
        "วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ",
        "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"
    )

    fun toBuddhistYear(gregorianYear: Int): Int = gregorianYear + 543

    fun toGregorianYear(buddhistYear: Int): Int = buddhistYear - 543

    fun getMonthNameTh(month: Int): String {
        return if (month in 1..12) THAI_MONTHS_FULL[month - 1] else ""
    }

    fun getMonthShortNameTh(month: Int): String {
        return if (month in 1..12) THAI_MONTHS_SHORT[month - 1] else ""
    }

    fun getDayOfWeekNameTh(date: LocalDate): String {
        val index = when (date.dayOfWeek) {
            DayOfWeek.SUNDAY -> 0
            DayOfWeek.MONDAY -> 1
            DayOfWeek.TUESDAY -> 2
            DayOfWeek.WEDNESDAY -> 3
            DayOfWeek.THURSDAY -> 4
            DayOfWeek.FRIDAY -> 5
            DayOfWeek.SATURDAY -> 6
        }
        return THAI_DAYS_OF_WEEK_FULL[index]
    }

    fun formatFullThaiDate(date: LocalDate): String {
        val dayOfWeek = getDayOfWeekNameTh(date)
        val day = date.dayOfMonth
        val month = getMonthNameTh(date.monthValue)
        val bYear = toBuddhistYear(date.year)
        return "$dayOfWeek $day $month พ.ศ. $bYear"
    }

    fun formatShortThaiDate(date: LocalDate): String {
        val day = date.dayOfMonth
        val month = getMonthShortNameTh(date.monthValue)
        val bYear = toBuddhistYear(date.year)
        return "$day $month $bYear"
    }

    fun getHolidaysForYear(year: Int): List<ThaiHoliday> {
        val holidays = mutableListOf<ThaiHoliday>()

        // Fixed Solar Public Holidays
        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 1, 1),
                nameTh = "วันขึ้นปีใหม่",
                nameEn = "New Year's Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันเฉลิมฉลองเริ่มต้นปีพุทธศักราชใหม่ และวันหยุดราชการประจำปี"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 4, 6),
                nameTh = "วันจักรี",
                nameEn = "Chakri Memorial Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันระลึกถึงพระบาทสมเด็จพระพุทธยอดฟ้าจุฬาโลกมหาราชและมหาจักรีบรมราชวงศ์"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 4, 13),
                nameTh = "วันสงกรานต์",
                nameEn = "Songkran Festival (Day 1)",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันขึ้นปีใหม่ไทย วันผู้สูงอายุแห่งชาติ ประเพณีรดน้ำดำหัว"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 4, 14),
                nameTh = "วันสงกรานต์ / วันครอบครัว",
                nameEn = "Songkran Festival (Day 2)",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันสงกรานต์และวันครอบครัวแห่งชาติ"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 4, 15),
                nameTh = "วันสงกรานต์",
                nameEn = "Songkran Festival (Day 3)",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันสงกรานต์ สรงน้ำพระและเฉลิมฉลองเทศกาลสงกรานต์"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 5, 1),
                nameTh = "วันแรงงานแห่งชาติ",
                nameEn = "National Labour Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันหยุดของผู้ใช้แรงงานและภาคเอกชน/ธนาคาร"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 5, 4),
                nameTh = "วันฉัตรมงคล",
                nameEn = "Coronation Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันพระราชพิธีบรมราชาภิเษกพระบาทสมเด็จพระวชิรเกล้าเจ้าอยู่หัว"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 6, 3),
                nameTh = "วันเฉลิมพระชนมพรรษาสมเด็จพระนางเจ้าฯ พระบรมราชินี",
                nameEn = "Queen Suthida's Birthday",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันเฉลิมพระชนมพรรษาสมเด็จพระนางเจ้าสุทิดา พัชรสุธาพิมลลักษณ พระบรมราชินี"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 7, 28),
                nameTh = "วันเฉลิมพระชนมพรรษาพระบาทสมเด็จพระวชิรเกล้าเจ้าอยู่หัว (ร.10)",
                nameEn = "King Maha Vajiralongkorn's Birthday",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันเฉลิมพระชนมพรรษาพระบาทสมเด็จพระปรเมนทรรามาธิบดีศรีสินทรมหาวชิราลงกรณ พระวชิรเกล้าเจ้าอยู่หัว"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 8, 12),
                nameTh = "วันแม่แห่งชาติ / วันเฉลิมพระชนมพรรษาสมเด็จพระบรมราชชนนีพันปีหลวง",
                nameEn = "National Mother's Day / Queen Sirikit's Birthday",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันแม่แห่งชาติ และวันเฉลิมพระชนมพรรษาสมเด็จพระนางเจ้าสิริกิติ์ พระบรมราชินีนาถ พระบรมราชชนนีพันปีหลวง"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 10, 13),
                nameTh = "วันนวมินทรมหาราช",
                nameEn = "King Bhumibol Adulyadej Memorial Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันคล้ายวันสวรรคตพระบาทสมเด็จพระบรมชนกาธิเบศร มหาภูมิพลอดุลยเดชมหาราช บรมนาถบพิตร"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 10, 23),
                nameTh = "วันปิยมหาราช",
                nameEn = "Chulalongkorn Memorial Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันคล้ายวันสวรรคตพระบาทสมเด็จพระจุลจอมเกล้าเจ้าอยู่หัว (รัชกาลที่ 5)"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 12, 5),
                nameTh = "วันพ่อแห่งชาติ / วันชาติ",
                nameEn = "National Father's Day / King Bhumibol's Birthday",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันคล้ายวันพระบรมราชสมภพพระบาทสมเด็จพระบรมชนกาธิเบศร มหาภูมิพลอดุลยเดชมหาราช บรมนาถบพิตร วันชาติ และวันพ่อแห่งชาติ"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 12, 10),
                nameTh = "วันรัฐธรรมนูญ",
                nameEn = "Constitution Day",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันระลึกถึงพระบาทสมเด็จพระปกเกล้าเจ้าอยู่หัว พระราชทานรัฐธรรมนูญฉบับถาวรฉบับแรก"
            )
        )

        holidays.add(
            ThaiHoliday(
                date = LocalDate.of(year, 12, 31),
                nameTh = "วันสิ้นปี",
                nameEn = "New Year's Eve",
                category = HolidayCategory.PUBLIC_HOLIDAY,
                description = "วันส่งท้ายปีเก่า ต้อนรับปีใหม่"
            )
        )

        // Lunar Buddhist Holidays (Specific per year calculations for Thai Buddhist calendar)
        when (year) {
            2024 -> {
                holidays.add(ThaiHoliday(LocalDate.of(2024, 2, 24), "วันมาฆบูชา", "Makha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 3 วันจาตุรงคสันนิบาต"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 2, 26), "วันหยุดชดเชยวันมาฆบูชา", "Substitution for Makha Bucha", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันมาฆบูชา"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 4, 8), "วันหยุดชดเชยวันจักรี", "Substitution for Chakri Day", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันจักรี"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 4, 16), "วันหยุดชดเชยวันสงกรานต์", "Substitution for Songkran", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันสงกรานต์"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 5, 10), "วันพืชมงคล", "Royal Ploughing Ceremony", HolidayCategory.PUBLIC_HOLIDAY, "วันพระราชพิธีพืชมงคลจรดพระนังคัลแรกนาขวัญ"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 5, 22), "วันวิสาขบูชา", "Visakha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 6 วันประสูติ ตรัสรู้ และปรินิพพาน"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 7, 20), "วันอาสาฬหบูชา", "Asalha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 8 แสดงปฐมเทศนา"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 7, 21), "วันเข้าพรรษา", "Buddhist Lent Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันแรม 1 ค่ำ เดือน 8 เริ่มต้นจำพรรษา 3 เดือน"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 7, 22), "วันหยุดชดเชยวันอาสาฬหบูชา", "Substitution for Asalha Bucha", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันอาสาฬหบูชา"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 7, 29), "วันหยุดชดเชยวันเฉลิมพระชนมพรรษา ร.10", "Substitution for King's Birthday", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันเฉลิมพระชนมพรรษา ร.10"))
                holidays.add(ThaiHoliday(LocalDate.of(2024, 10, 14), "วันหยุดชดเชยวันนวมินทรมหาราช", "Substitution for Memorial Day", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันนวมินทรมหาราช"))
            }
            2025 -> {
                holidays.add(ThaiHoliday(LocalDate.of(2025, 2, 12), "วันมาฆบูชา", "Makha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 3 วันจาตุรงคสันนิบาต"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 4, 7), "วันหยุดชดเชยวันจักรี", "Substitution for Chakri Day", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันจักรี"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 5, 5), "วันหยุดชดเชยวันฉัตรมงคล", "Substitution for Coronation Day", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันฉัตรมงคล"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 5, 9), "วันพืชมงคล", "Royal Ploughing Ceremony", HolidayCategory.PUBLIC_HOLIDAY, "วันพระราชพิธีพืชมงคลจรดพระนังคัลแรกนาขวัญ"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 5, 11), "วันวิสาขบูชา", "Visakha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 6 วันสำคัญสากลของโลก"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 5, 12), "วันหยุดชดเชยวันวิสาขบูชา", "Substitution for Visakha Bucha", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันวิสาขบูชา"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 7, 10), "วันอาสาฬหบูชา", "Asalha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 8 แสดงปฐมเทศนา ธัมมจักกัปปวัตตนสูตร"))
                holidays.add(ThaiHoliday(LocalDate.of(2025, 7, 11), "วันเข้าพรรษา", "Buddhist Lent Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันแรม 1 ค่ำ เดือน 8"))
            }
            2026 -> {
                holidays.add(ThaiHoliday(LocalDate.of(2026, 3, 3), "วันมาฆบูชา", "Makha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 3 วันจาตุรงคสันนิบาต"))
                holidays.add(ThaiHoliday(LocalDate.of(2026, 5, 8), "วันพืชมงคล", "Royal Ploughing Ceremony", HolidayCategory.PUBLIC_HOLIDAY, "วันพระราชพิธีพืชมงคลจรดพระนังคัลแรกนาขวัญ"))
                holidays.add(ThaiHoliday(LocalDate.of(2026, 5, 31), "วันวิสาขบูชา", "Visakha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 6 วันประสูติ ตรัสรู้ และปรินิพพาน"))
                holidays.add(ThaiHoliday(LocalDate.of(2026, 6, 1), "วันหยุดชดเชยวันวิสาขบูชา", "Substitution for Visakha Bucha", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันวิสาขบูชา"))
                holidays.add(ThaiHoliday(LocalDate.of(2026, 7, 29), "วันอาสาฬหบูชา", "Asalha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 8"))
                holidays.add(ThaiHoliday(LocalDate.of(2026, 7, 30), "วันเข้าพรรษา", "Buddhist Lent Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันแรม 1 ค่ำ เดือน 8"))
            }
            2027 -> {
                holidays.add(ThaiHoliday(LocalDate.of(2027, 2, 21), "วันมาฆบูชา", "Makha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 3"))
                holidays.add(ThaiHoliday(LocalDate.of(2027, 2, 22), "วันหยุดชดเชยวันมาฆบูชา", "Substitution for Makha Bucha", HolidayCategory.SUBSTITUTE_HOLIDAY, "วันหยุดชดเชยวันมาฆบูชา"))
                holidays.add(ThaiHoliday(LocalDate.of(2027, 5, 14), "วันพืชมงคล", "Royal Ploughing Ceremony", HolidayCategory.PUBLIC_HOLIDAY, "วันพระราชพิธีพืชมงคล"))
                holidays.add(ThaiHoliday(LocalDate.of(2027, 5, 20), "วันวิสาขบูชา", "Visakha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 6"))
                holidays.add(ThaiHoliday(LocalDate.of(2027, 7, 18), "วันอาสาฬหบูชา", "Asalha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 8"))
                holidays.add(ThaiHoliday(LocalDate.of(2027, 7, 19), "วันเข้าพรรษา", "Buddhist Lent Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันแรม 1 ค่ำ เดือน 8"))
            }
            else -> {
                // Approximate fallback for other years
                holidays.add(ThaiHoliday(LocalDate.of(year, 2, 20), "วันมาฆบูชา", "Makha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 3"))
                holidays.add(ThaiHoliday(LocalDate.of(year, 5, 15), "วันวิสาขบูชา", "Visakha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 6"))
                holidays.add(ThaiHoliday(LocalDate.of(year, 7, 20), "วันอาสาฬหบูชา", "Asalha Bucha Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันขึ้น 15 ค่ำ เดือน 8"))
                holidays.add(ThaiHoliday(LocalDate.of(year, 7, 21), "วันเข้าพรรษา", "Buddhist Lent Day", HolidayCategory.BUDDHIST_HOLIDAY, "วันแรม 1 ค่ำ เดือน 8"))
            }
        }

        // Add auto compensatory off-days for fixed holidays falling on Saturday or Sunday
        val originalFixed = holidays.filter { it.category == HolidayCategory.PUBLIC_HOLIDAY }
        for (h in originalFixed) {
            if (h.date.dayOfWeek == DayOfWeek.SATURDAY) {
                val subDate = h.date.plusDays(2)
                if (holidays.none { it.date == subDate }) {
                    holidays.add(
                        ThaiHoliday(
                            date = subDate,
                            nameTh = "วันหยุดชดเชย${h.nameTh}",
                            nameEn = "Substitution for ${h.nameEn}",
                            category = HolidayCategory.SUBSTITUTE_HOLIDAY,
                            description = "วันหยุดชดเชย${h.nameTh} (ตรงกับวันเสาร์)"
                        )
                    )
                }
            } else if (h.date.dayOfWeek == DayOfWeek.SUNDAY) {
                val subDate = h.date.plusDays(1)
                if (holidays.none { it.date == subDate }) {
                    holidays.add(
                        ThaiHoliday(
                            date = subDate,
                            nameTh = "วันหยุดชดเชย${h.nameTh}",
                            nameEn = "Substitution for ${h.nameEn}",
                            category = HolidayCategory.SUBSTITUTE_HOLIDAY,
                            description = "วันหยุดชดเชย${h.nameTh} (ตรงกับวันอาทิตย์)"
                        )
                    )
                }
            }
        }

        return holidays.sortedBy { it.date }
    }

    fun getHoliday(date: LocalDate): ThaiHoliday? {
        val list = getHolidaysForYear(date.year)
        return list.firstOrNull { it.date == date }
    }

    // Thai Wan Phra (Buddhist Holy Days) dates catalog for 2024-2027
    fun getWanPhraDaysForYear(year: Int): List<WanPhraDay> {
        val list = mutableListOf<WanPhraDay>()
        // Generate key Wan Phra days based on the lunar synodic month (approx every 7-8 days)
        // We calibrate to exact known Thai lunar anchor dates
        val anchor = when (year) {
            2024 -> LocalDate.of(2024, 1, 4)
            2025 -> LocalDate.of(2025, 1, 7)
            2026 -> LocalDate.of(2026, 1, 2)
            2027 -> LocalDate.of(2027, 1, 7)
            else -> LocalDate.of(year, 1, 5)
        }

        val stepDays = listOf(7, 8, 7, 7)
        var currentDate = anchor
        var phaseIdx = 0
        val phases = listOf("ขึ้น ๘ ค่ำ", "ขึ้น ๑๕ ค่ำ (วันเพ็ญ)", "แรม ๘ ค่ำ", "แรม ๑๔/๑๕ ค่ำ")

        while (currentDate.year <= year) {
            if (currentDate.year == year) {
                list.add(
                    WanPhraDay(
                        date = currentDate,
                        descriptionTh = "วันพระ (${phases[phaseIdx % phases.size]})"
                    )
                )
            }
            val step = stepDays[phaseIdx % stepDays.size]
            currentDate = currentDate.plusDays(step.toLong())
            phaseIdx++
        }
        return list
    }

    fun isWanPhra(date: LocalDate): WanPhraDay? {
        return getWanPhraDaysForYear(date.year).firstOrNull { it.date == date }
    }
}
