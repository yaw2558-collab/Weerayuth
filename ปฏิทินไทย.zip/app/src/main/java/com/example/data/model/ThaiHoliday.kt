package com.example.data.model

import java.time.LocalDate

enum class HolidayCategory(val thaiName: String) {
    PUBLIC_HOLIDAY("วันหยุดราชการ"),
    BUDDHIST_HOLIDAY("วันสำคัญทางศาสนา"),
    NATIONAL_OBSERVANCE("วันสำคัญของชาติ"),
    SUBSTITUTE_HOLIDAY("วันหยุดชดเชย")
}

data class ThaiHoliday(
    val date: LocalDate,
    val nameTh: String,
    val nameEn: String,
    val category: HolidayCategory,
    val description: String = "",
    val isOffDay: Boolean = true
)

data class WanPhraDay(
    val date: LocalDate,
    val descriptionTh: String // e.g. "ขึ้น ๑๕ ค่ำ เดือน ๑๐"
)
