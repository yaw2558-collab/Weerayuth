package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calendar_events")
data class CalendarEvent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateString: String, // Format: YYYY-MM-DD
    val title: String,
    val description: String = "",
    val timeString: String = "", // e.g. "09:00"
    val isPushNotificationEnabled: Boolean = true,
    val colorHex: String = "#E53935",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notification_logs")
data class NotificationLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val message: String,
    val type: String, // "HOLIDAY", "REMINDER", "TEST"
    val timestamp: Long = System.currentTimeMillis()
)
