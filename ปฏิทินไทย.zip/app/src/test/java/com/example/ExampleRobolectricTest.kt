package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ThaiDateUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ปฏิทินไทย", appName)
  }

  @Test
  fun `test thai buddhist year conversion`() {
    assertEquals(2569, ThaiDateUtils.toBuddhistYear(2026))
    assertEquals(2568, ThaiDateUtils.toBuddhistYear(2025))
    assertEquals("มกราคม", ThaiDateUtils.getMonthNameTh(1))
    assertEquals("ธันวาคม", ThaiDateUtils.getMonthNameTh(12))
  }

  @Test
  fun `test thai holidays catalog`() {
    val holidays2026 = ThaiDateUtils.getHolidaysForYear(2026)
    assertNotNull(holidays2026)
    assert(holidays2026.isNotEmpty())

    val songkran = holidays2026.find { it.nameTh.contains("สงกรานต์") }
    assertNotNull(songkran)
    assertEquals(LocalDate.of(2026, 4, 13), songkran?.date)
  }
}
